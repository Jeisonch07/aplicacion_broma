﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Menu1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //ESTE ES UN PROGRAMA TRAMPA AL DAR AL BOTON NO HARA QUE SE DESPLACE ASIA CUALQUIER LADO
        //Y AL PRESIONAR SI NOS SALDRA UN MENSAJE EN LA PANTALA DE QUE FUE ACTUALIZADO.

        private void btnSi_Click(object sender, EventArgs e)
        {
            MessageBox.Show("¡Tu pc se esta actualizando!");
        }

        private void btnNo_Click(object sender, EventArgs e)
        {
            // Calcula nuevas coordenadas para el botón (puedes ajustar estos valores según tus necesidades)
            int newX = btnSi.Location.X + 10; // Mueve 10 píxeles a la derecha
            int newY = btnSi.Location.Y + 10; // Mueve 10 píxeles hacia abajo

            // Establece las nuevas coordenadas para el botón
            btnSi.Location = new Point(newX, newY);
        }
    }
}
